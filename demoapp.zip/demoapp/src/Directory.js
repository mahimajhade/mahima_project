import React, { useState } from "react";
import './Folder.css'
import { FileIcon } from 'react-file-icon';
import { FaFile } from "react-icons/fa";


const Directory = ({files}) => {
   const [expandedData,toggleExpandedData] = useState(false);

   if(files.type === "file"){ 
    return(
        <div>
           
           <FaFile/><h1 className="folder-css">{files.name}</h1>
    
        </div>
    )
   }
    return (
        <div className="folder-css">
            <h1 onClick={()=> toggleExpandedData(!expandedData)}>{files.name}</h1>
            {  
             expandedData && files.items.map((item) => <Directory files={item}/>             
          )
            }
        </div>
    )
}

export default Directory;

